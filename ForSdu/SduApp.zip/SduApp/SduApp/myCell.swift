//
//  myCell.swift
//  SduApp
//
//  Created by Demeuov Daulet on 05.03.2018.
//  Copyright © 2018 Demeuov Daulet. All rights reserved.
//

import UIKit

class myCell: UICollectionViewCell {
    
}
